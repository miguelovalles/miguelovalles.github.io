*** This is a read me file explaining what each file in the zip file is. ***

File 1: Final Project Zoo Authentication Miguel Ovalles.docx is the file that contains my pseudocode as well as the remaining written portions of the final project.

File 2: md5digest is the provided java program for confirming the users credentials.

File 3: admin, veterinarian and zookeeper files are the files associated with each role of each user. The text inside the files will be displayed for the user when they log in.

File 4: zooAuthentication folder is a project folder output from netbeans. This project folder contains the classes split up.

File 5: authenticationSystem.java contains the full program including all classes as one file. Can be used to execute if needed.

File 6: credentials.txt file is the file that contains the user's credentials and where the program confirms the credentials. Provided as part of the class.

File 7 and 8: zooAuthentication.java and userInputs.java are files are files that contain the code. When working in Netbeans it split up the classes and I saved them as individual files.
		The userInputs file contains the class for the user inputs and the zooAuthentication contains the prompts class and the main class.