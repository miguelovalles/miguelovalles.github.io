public class userInputs{
    
        String userName;                           //Initializing username input
        String userPassword;			 //Initializing user password input

        /* assigning file path and file names */
        
        String filesPath;
        String credentialsFile;     
        
        /* created strings to use for accessing files when printing user roles */
        
        String zookeeper;    //Not currently used
        String admin;        //Not currently used
        String veterinarian; //Not currently used 
		String intern;		 //Not currently used  /* Added intern sring for new updates */
		
        int loginAttempts;    //Initializing login attempts as an integer
                
}